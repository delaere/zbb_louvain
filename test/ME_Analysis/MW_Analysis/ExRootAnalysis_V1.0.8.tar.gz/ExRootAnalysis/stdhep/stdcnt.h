/*
    StdHep counting common block
*/
struct stdcnt {
    int nstdwrt;	/* number of events written */
    int nstdrd;		/* number of events read */
    int nlhwrt;		/* number of Les Houches events written */
    int nlhrd;		/* number of Les Houches events read */
};
